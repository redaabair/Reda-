R32 Basic Project - Initial Setup
Includes: Basic Scene & Placeholder Assets